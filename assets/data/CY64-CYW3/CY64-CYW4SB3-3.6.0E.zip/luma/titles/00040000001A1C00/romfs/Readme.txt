"en" holds things like the help page and the GRPs for the top menu and the basic keyboard/dialog/file manager.

The SYS folder is exactly what it says.
SB3's file explorer will only show expected files (y'know, the tools and the examples) and any custom file will not show up, even in a FILES listing.
They are still accessible with LOAD commands though and CHKFILE'able.

I made the patch to make themes and change SYS folder contents. I would like to improve the SmileTool without having the weird behaviour you get when the tool is in a writable folder (i.e. not in the SYS folder)

The default font was updated. Should you not want it, just remove the BDEFFONT.GRP file.

Included as well:
- Th.GED Editor (with LohadL's translation)
