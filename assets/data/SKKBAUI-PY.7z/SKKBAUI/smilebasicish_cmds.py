from pygame.draw import *
from pygame.font import *
antialias=True
gputchr_x=0
gputchr_y=0

# getGputchrSize()
#
# Returns the box size of the last gputchr() or gputstr() executed.
#

def getGputchrSize():
		return (gputchr_x,gputchr_y)

def gcircle(screen,x,y,rd,w,r,g,b):
		color=(min(255,max(r,0)),min(255,max(g,0)),min(255,max(b,0)))
		pos=(x,y)
		circle(screen, color, pos, rd, w)

def gbox(screen,x0,y0,x1,y1,r,g,b,w):
		color=(min(255,max(r,0)),min(255,max(g,0)),min(255,max(b,0)))
		rct=((x0,y0),(x1,y1))
		rect(screen,color,rct,w)

def gputchr(screen,x,y,str,r,g,b,sz=12,align=0,font="nintendo_NTLG-DB_002, nintendo_udsg-r_std_003, M+ 1p, Unifont, Microsoft JhengHei, Verdana, Tahoma, Arial"):
		gputchr_x=0
		gputchr_y=sz+sz/3
		font = SysFont(font, sz)
		text = font.render(str, antialias, (min(255,max(r,0)),min(255,max(g,0)),min(255,max(b,0))))
		if align==2:
			screen.blit(text, (x-text.get_width(), y))
		elif align==1:
			screen.blit(text, (x-text.get_width()//2, y))
		else:
			screen.blit(text, (x, y))
		gputchr_x=text.get_width()
		
def gputstr(screen,x,y,str,r,g,b,sz=12,align=0,h=16,font="nintendo_NTLG-DB_002, nintendo_udsg-r_std_003, M+ 1p, Unifont, Microsoft JhengHei, Verdana, Tahoma, Arial"):
		gputchr_x=0
		gputchr_y=0
		strs = str.splitlines()
		font = SysFont(font,sz)
		for i in strs:
			text = font.render(i, antialias, (min(255,max(r,0)),min(255,max(g,0)),min(255,max(b,0))))
			if align==2:
				screen.blit(text, (x-text.get_width(), y))
			elif align==1:
				screen.blit(text, (x-text.get_width()//2, y))
			else:
				screen.blit(text, (x, y))
			y += h
			gputchr_x=max(gputchr_x,text.get_width())
			gputchr_y=y+h

def gline(screen,x0,y0,x1,y1,r,g,b,w):
		color=(min(255,max(r,0)),min(255,max(g,0)),min(255,max(b,0)))
		line(screen,color,(x0,y0),(x1,y1),w)
