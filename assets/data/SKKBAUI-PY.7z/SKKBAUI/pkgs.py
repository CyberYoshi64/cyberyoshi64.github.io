def Dummy(wid,x,y,w,h):
		WindowDrag(wid)
		gputchr(wsurface,x,y,"lol",0,0,0,12,0)
		WindowClose(wid)
