#!/usr/bin/env python3
# coding=utf-8

# 
# サカキバラUI: Python edition
# 
# 2020 サイバーヨッシー６４
# 

# --------------------------------------------------------------------------------------------------------------------------------------------
# Apps

def Dummy(wid, x, y, w, h):
		global mouseDown, mouseUp, keyCode                                                        # Make globals are writable from here
		WindowDrag(wid)                                                                           # Let window be draggable
		gputchr(wsurface,random.randint(0,w),random.randint(0,h),"Hello world!",0,0,0,16)         # draw "Hello world" at randomized position
		gputchr(wsurface,w/2,h-16,"Right-click on the window to close it.",0,0,0,12,1)            # draw message to close window by right-clicking it
		if IsMouseInWindow(wid) and mouseUp == 3:                                                 # Check, whether the mouse is hovering over the window and user is right-clicking it
				WindowDestroy(wid)                                                                    # Close window instantly
				mouseUp=0                                                                             # Reset global to prevent clicking through windows
		WindowClose(wid)                                                                          # Render a close button (Type-1-windows only)


#
# Here you can add more apps. The below ones are pre-made apps
#


def Startmenu(wid, x, y, w, h):
		global mouseDown, mouseUp, keyCode, skkbashutdown
		
		if mouseX > x and mouseY > y and mouseX < x+w and mouseY < y+18:
				if mouseDown==1:
						gbox(wsurface,0,0,w,18,favcr/4,favcg/4,favcb/4,0)
				elif mouseUp==1:
						mouseUp=0
						WindowInit(1,"AboutSKKBAUI",lng[24],0,(favcr/2,favcg/2,favcb/2),4,4,256,200)
				else:
						gbox(wsurface,0,0,w,18,favcr/2,favcg/2,favcb/2,0)

		if mouseX > x and mouseY > y+h-18 and mouseX < x+w and mouseY < y+h:
				if mouseDown==1:
						gbox(wsurface,0,h-18,w,18,favcr/4,favcg/4,favcb/4,0)
				elif mouseUp==1:
						mouseUp=0
						skkbashutdown=1
				else:
						gbox(wsurface,0,h-18,w,18,favcr/2,favcg/2,favcb/2,0)

		gputchr(wsurface,2,1,lng[23],255,255,255,12)
		gputchr(wsurface,2,17,lng[25],255,255,255,12)
		gputchr(wsurface,2,h-17,lng[26],255,255,255,12)
		if (not IsMouseInWindow(wid) and mouseUp > 0 and mouseUp < 4) or not wid==app_focus:
				WindowDestroy(wid)

def AboutSKKBAUI(wid,x,y,w,h):
		global AboutSKKBAUI_image
		if WindowOnOpen(wid):
				AboutSKKBAUI_image, void = load_png("AboutSKKBAUI","logo.png")
		WindowDrag(wid)
		wsurface.blit(AboutSKKBAUI_image, (8,8))
		gputchr(wsurface,48+(w-24)/2,16,lng[0],255,255,255,24,1,"nintendoNTLG-DB_002,Microsoft JhengHei")
		gputchr(wsurface,48+(w-24)/2,46,lng[1],255,255,255,10,1,"nintendoNTLG-DB_002,Microsoft JhengHei")
		gputstr(wsurface,w/2,80,"サカキバラUI: Python edition is a fan-\nmade mock OS and may be redistributed\nand modified for free. But when doing so,\nplease credit me. That would be highly\nappreciated.",255,255,255,12,1,14,"nintendoNTLG-DB_002,Microsoft JhengHei")
		WindowClose(wid)

# --------------------------------------------------------------------------------------------------------------------------------------------
# Start of special globals
# Please don't mess with those if you write custom apps.

VERSION = "0.1"      # reported Version
lang = "en_us"       # reported language (currently only 'en_us' and 'de_de' allowed)
fullscreenmode=False  # enter fullscreen mode (display may be scaled)
viewportw=1280       # Viewport width (Display width)
viewporth=720        # Viewport height (Display height)
favcr=48             # Theme color (Red component)
favcg=96             # Theme color (Grenn component)
favcb=192            # Theme color (Blue component)
app_limit=10         # Number of apps allowed to run at the same time
keyRepeat_s=12       # Key repeat start
keyRepeat_d=2        # Key repeat interval
languagepacklinesmin=512 # Language pack entries expected
blankscrbyafk=1200   # Amount of jiffies to blank screen if user is AFK

# --------------------------------------------------------------------------------------------------------------------------------------------
# Start of main code
# Please don't mess with the below code if you write custom apps.

app_amount=0 # Number of apps opened at the time
maincnt=0    # Jiffy counter (Counts up every 1/60th of a secound)
notifys=0    # Number of notification pop-ups opened
notify_s=[]   # Data for notification strings
notify_t=[]   # Data for notification timers
notify_x=[]   # Data for notification position

try:
		import sys                       # System calls and session exit
		import random                    # Randomness
		import math                      # Advanced math functions
		import os                        # File system
		import datetime                  # Retrieve date and time for taskbar display
		import pygame                    # The key component of this session
		from smilebasicish_cmds import * # have SmileBASIC-ish commands, like gputchr()
		from pygame.locals import *      # Pygame init
		from pygame.draw import *        # Pygame init
except ImportError as e:
		print("couldn't load modules\n{}.".format(e)) # Could not load all packages because one of them
		sys.exit(2)                                 # might be missing or not installed.

def load_png(dir,name):

		""" Load image and return image object"""

		fullname = os.path.join('assets', dir, name) # look for /assets/[dir]/[name]
		try:
				image = pygame.image.load(fullname)      # load image to memory
				if image.get_alpha is None:              # if image doesn't contain alpha channel...
						image = image.convert()              # ...convert it to RGB
				else:                                    # else ...
						image = image.convert_alpha()        # ... convert it to RGBA
		except pygame.error:                         # if an error occures... (such as file being corrupted or missing)
				print(lng[18], fullname)                 # ...Inform user about it
				raise SystemExit                         # ...Force quit SKKBAUI (as it can't operate like that)
		return image, image.get_rect()               # else give image data back to the sprite that wanted it

def renderNotify(): # W.I.P.
		global notify_x,notify_t
		i=0
		for i in range(0,min(8,max(0,notifys))):
				gbox(sysscr,viewportw-notify_x[i],viewporth-120-i*80,400,76,favcr,favcg,favcb,0)
				gputstr(sysscr,viewportw+4-notify_x[i],viewporth-116-i*80,notify_s[i],255,255,255)
				notify_t[i] += -1
				if notify_t[i] > 15:
						notify_x[i] = ( notify_x[i] * 7 + 399 ) / 8
				else:
						notify_x[i] = notify_x[i] * 0.75
				if notify_x[i] < 2 and notify_t[i] < 15:
						NotifyRemove(i)
						break
				if mouseX > viewportw-notify_x[i] and mouseY > viewporth-120-i*80 and mouseY < viewporth-44-i*80 and mouseUp==1:
						notify_t[i] = 10

def NotifyPush(str,time): # Push a notification
		global notifys, notify_x, notify_s, notify_t
		notifys += 1
		if time < 0:
				time = 300
		notify_x.append(0)
		notify_t.append(time)
		notify_s.append(str)

def NotifyRemove(id): # Internal use only
		global notifys, notify_x, notify_s, notify_t
		try:
				notifys += -1
				notify_s.pop(id)
				notify_x.pop(id)
				notify_t.pop(id)
		except ValueError or IndexError:
				print("NotifyRemove(): "+lng[16]+": "+lng[19])

class Taskbar(pygame.sprite.Sprite):
		"""
		Sakakibara UI taskbar

		Show current processes during the session

		"""

		def __init__(self):                                         # Sprite's initialization
			pygame.sprite.Sprite.__init__(self)                       # Initializing this sprite as one
			self.image, self.rect = load_png('taskbar','taskbar.png') # Request the taskbar image

		def update(self):
			self.image = pygame.transform.scale(self.image, (viewportw, 32)) # Scale image to fit the viewport (display width)
			self.rect=(0,viewporth-32,viewportw,viewporth)                   # Put taskbar on bottom of the screen

		def puttaskboxes(self):              # Draw boxes for each task running
			global app_killed                  # Ensure that the destroyed windows are being noticed (ensure writability to that global)
			j=-1                               # Counter for drawed box
			for i in range(0,app_amount):      # For loop going through all tasks in the list

				if wintype[i] == 1:              # Is the window with the current ID (i) a Type-1-window?
				                                 # If it is...
						j += 1                       # increment box counter

						tmp0=(mouseX > 40+160*j and mouseY > viewporth-28 and mouseX < 192+160*j and mouseY < viewporth-2)
						# ... make a variable determining color when mouse hovers over the box

						tmp1=(mouseX > 40+160*j and mouseY > viewporth-28 and mouseX < 192+160*j and mouseY < viewporth-2 and (mouseDown > 0 and mouseDown < 4))
						# ... make another variable determining color when mouse is clicking on the box

						boxsurf = pygame.surface.Surface((152,24))
						# ... make a surface to draw the box on (prevent overflowing)

						gbox(boxsurf, 0, 0, 152, 24, int(favcr * 1.2)+64*tmp0-110*tmp1, int(favcg * 1.2)+64*tmp0-110*tmp1, int(favcb * 1.2)+64*tmp0-110*tmp1,0)
						# ... draw the box with the above 2 variables determining the color of the box along wwoth the theme color

						gputchr(boxsurf, 4, 4,dispname[i],255-tmp1*55,255-tmp1*55,255-tmp1*55,12,0)
						# ... draw the window's name on the box

						sysscr.blit(boxsurf, (40+160*j, viewporth-28)) # ... Draw the box with the name onto the screen at the position specified by j

						if tmp0 and mouseUp==2:
								WindowDestroy(winid[i])

						if i+1 > app_amount-app_killed:
								app_killed=0
								break
				if (50+(j+1)*160) > viewportw-260:   # If next box would write over the taskbar time...
						break                        # ... then break out of the loop



class StartButton(pygame.sprite.Sprite):
		"""
		Sakakibara UI start button

		Sit there for a click

		"""

		def __init__(self):                                               # Sprite's intialization
				pygame.sprite.Sprite.__init__(self)                           # Initializing this sprite as one
				self.image, self.rect = load_png('taskbar','startbutton.png') # Request the start button image

		def update(self):                                        # Update sprite routine
				global mouseUp                                       # Allow global to be writable from here
				self.rect=(0,viewporth-32,32,viewporth)              # Place the start button on the bottom left of the viewport (screen)
				if mouseX<32 and mouseY>viewporth-32 and mouseUp==1 and GetWindowByDEF("Startmenu")==-1: # If this button is clicked...
						WindowInit(0,"Startmenu",lng[22],0,(favcr*0.8,favcg*0.8,favcb*0.8),2,viewporth-194,240,160)
						mouseUp=0
						# Initialize the start menu and prevent it from closing immediately

		def startbtnborder(self):                                     # Render a border on the start button
				tmp0=(mouseX<32 and mouseY>viewporth-32)                  # Determine color when start button is being hovered over by the mouse
				tmp1=(mouseX<32 and mouseY>viewporth-32 and mouseDown==1) # Determine color when start button is being clicked on by the mouse
				gcircle(sysscr,16,viewporth-16,16,4,92+tmp0*55-128*tmp1,200+tmp0*55-128*tmp1,200+tmp0*55-128*tmp1) # Draw the border on the button


def WindowInit(type,fname,name,bnrcol,bckcol,x,y,w,h): # Window initialization
		global app_amount            # Ensure global to be writable form here, so it can be rendered
		if app_amount < app_limit:   # If there is room for another window...

				print("WindowInit("+str(type)+",'"+fname+"','"+name+"',"+str(bnrcol)+","+str(bckcol)+","+str(x)+","+str(y)+","+str(w)+","+str(h)+")")
				# Debug output

				app_amount += 1                # Increment number of currently opened apps by 1
				global app_focus               # Allow global to be written to from here
				app_focus = max(winid+[0])+1   # Set the new window to be the focussed one
				winid.append(max(winid+[0])+1) # Give the new window an ID
				wintype.append(type)           # Push attributes of the new window
				defname.append(fname)         # Push attributes of the new window
				dispname.append(name)          # Push attributes of the new window
				bckcolor.append(bckcol)        # Push attributes of the new window
				posx.append(x)                 # Push attributes of the new window
				posy.append(y)                 # Push attributes of the new window
				sizex.append(w)                # Push attributes of the new window
				sizey.append(h)                # Push attributes of the new window
				apptimer.append(0)             # Start up app timer for use with WindowOnOpen()
				return app_focus               # Give out the new window's ID

		else:   # If there's not enough room for a new window...
				
				NotifyPush("Not enough memory to spawn another window.\n\nTry closing other windows to free up space.",-1)
				print("WindowInit(): "+lng[17]+": "+lng[20])
				print("WindowInit(): "+lng[13]+": "+lng[21])
				return -1
				# Just tell the user and don't go ahead making the new window

def WindowOnOpen(wid):
	try:
		return apptimer[winid.index(wid)]==1
	except ValueError or IndexError:
		return False

def WindowDestroy(wid):                  # Window destruction (instant close)
		print("WindowDestroy("+str(wid)+")") # Debug output
		global app_focus                     # Allow global to be written to from here
		global app_amount                    # Allow global to be written to from here
		app_amount += -1                     # Decrement number of apps opened by 1
		global app_killed                    # Allow global to be written to from here
		app_killed += 1                      # Inform the loops to quit themselves earlier, as window is destroyed

		if wid == app_focus:                 # If the window has the focus...
				app_focus = -1                   # ... take it away

		try:                                 # Prevent SKKBAUI from crashing due to errors

				i=winid.index(wid)    # 
				if i < app_amount+1:  # 
					wintype.pop(i)      # 
					winid.pop(i)        # 
					defname.pop(i)      # Remove app entry from all arrays
					dispname.pop(i)     # to clear it away.
					bckcolor.pop(i)     # 
					posx.pop(i)         # 
					posy.pop(i)         # 
					sizex.pop(i)        # 
					sizey.pop(i)        # 
					apptimer.pop(i)     # 
		except ValueError or IndexError:                                                     # When index is out of bounds...
				print("WindowDestroy(): "+lng[16]+": "+lng[19]) # ... warn user about it and don't mess with anything

def WindowDrag(wid): # W.I.P.
	global app_dragged
	try:
		x = posx[winid.index(wid)]                                         # get offset from the left of the screen
		y = posy[winid.index(wid)]                                         # get offset from the top of the screen
		w = sizex[winid.index(wid)]                                        # get width of the window
		h = sizey[winid.index(wid)]                                        # get height of the window

		if ((mouseX > x and mouseY > y-18 and mouseX < x+w-32 and mouseY < y and wid == app_focus) or app_dragged==wid) and mousePressed==1:
				app_dragged = wid
		if app_dragged == wid:
				posx[winid.index(wid)] += mouserx
				posy[winid.index(wid)] += mousery

	except ValueError or IndexError:
			print("WindowDrag(): "+lng[16]+": "+lng[19])

def IsMouseInWindow(wid):                                                  # Check, whether mouse is hovering over the window

		try:                                                                   # Prevent SKKBAUI from crashing when index is out of bounds

				x = posx[winid.index(wid)]                                         # get offset from the left of the screen
				y = posy[winid.index(wid)]                                         # get offset from the top of the screen
				w = sizex[winid.index(wid)]                                        # get width of the window
				h = sizey[winid.index(wid)]                                        # get height of the window

				return mouseX > x and mouseY > y and mouseX < x+w and mouseY < y+h # output boolean
				                                                                   # False = Mouse is not hovering over the window
				                                                                   # True  = Mouse is hovering over the window

		except ValueError:                                                     # When index is out of bounds...
				print("IsMouseInWindow(): "+lng[16]+": "+lng[19])  # warn user about it and don't do anything else
				return 0                                                           # Junk value but window is gone anyway

def WindowClose(wid):                                    # draw a close button on the top-right of the window (Type-1-windows only)
	global mouseUp
	if wid==app_focus:
		try:

				y=posy[winid.index(wid)]
				w=posx[winid.index(wid)]+sizex[winid.index(wid)]
				if wintype[winid.index(wid)]==1:
						gbox(sysscr,w-19,y-14,19,12,255-128*(mouseX > w-22 and mouseY > y-14 and mouseX < w-1 and mouseY < y and mouseDown==1),0,0,0)
						if mouseX > w-22 and mouseY > y-14 and mouseX < w-1 and mouseY < y and wid != app_dragged and (mouseUp > 0 and mouseUp < 4):
								WindowDestroy(wid)
								mouseUp = 0
		except ValueError:
				print("WindowClose(): "+lng[16]+": "+lng[19])

def GetWindowByDEF(d3f):
		try:
				return defname.index(d3f)
		except ValueError:
				return -1

def GetWindowIDByDEF(d3f):
		try:
				return defname.index(d3f)
		except ValueError:
				return -1

# --------------------------------------------------------------------------------------------------------------------------------------------

# Main code
# The below code initializes the important variables and then gets into the main loop
# This will be less well explained. Only minor things.

def main():
		global viewportw, viewporth
		# Initialise screen
		pygame.init()
		global sysscr, fullscreenmode

		if fullscreenmode:
			sysscr = pygame.display.set_mode((viewportw, viewporth),pygame.FULLSCREEN)
		else:
			sysscr = pygame.display.set_mode((viewportw, viewporth))

		pygame.display.set_caption('SKKBAUI: Python edition')

		# Fill background
		background = pygame.Surface(sysscr.get_size())
		background = background.convert()
		background.fill((255,255,255))

		# Initialise variables
		global maincnt
		global viewportchange
		viewportchange=False
		global app_dragged
		app_dragged=-1
		global skkbashutdown
		skkbashutdown=0
		global defname
		defname=[]
		global wintype
		wintype=[]
		global winid
		winid=[]
		global dispname
		dispname=[]
		global bckcolor
		bckcolor=[]
		global posx
		posx=[]
		global posy
		posy=[]
		global sizex
		sizex=[]
		global sizey
		sizey=[]
		global apptimer
		apptimer=[]
		global systime
		global keyRepeat
		keyRepeat=0
		global keyRepeat_t
		keyRepeat_t=0
		global mouseX,mouseY,mouserx,mousery,mouseUp,mouseDown,mousePressed
		mouseUp=False
		mouseDown=False
		mouseX=viewportw//2
		mouseY=viewporth//2
		mousePressed=False
		mouserx=0
		mousery=0
		global app_killed, app_focus
		app_killed=0
		app_focus=-1
		global keyDown, keyUp
		keyDown = 0
		keyUp = 0
		global wsurface
		global afktime
		afktime=0
		
		global teststring

		# Initialise taskbar
		taskbar = Taskbar()
		startbtn = StartButton()

		# Initialise sprites
		sptaskbar = pygame.sprite.RenderPlain(taskbar)
		spstartbtn = pygame.sprite.RenderPlain(startbtn)

		# Blit everything to the screen
		sysscr.blit(background, (0, 0))
		pygame.display.flip()

		# Initialise clock
		clock = pygame.time.Clock()

		# Event loop
		while True:
				# Make sure the UI doesn't run at more than 60 frames per second
				clock.tick(60)

				mouserx, mousery = pygame.mouse.get_rel()
				mouseX, mouseY = pygame.mouse.get_pos()
				
				if mouseDown or keyDown or mouserx or mousery:
						afktime = maincnt + 0
				

				if (maincnt - afktime) < blankscrbyafk:
						systime=datetime.datetime.now()
						gbox(sysscr,0,0,viewportw,viewporth,favcr/2,favcg/2,favcb/2,0)
						gputstr(sysscr,viewportw-2,viewporth-50,teststring,favcr+64,favcg+64,favcb+64,10,2,-16)
						gputstr(sysscr,viewportw//2,0,str(int(maincnt/6)/10)+"s passed\nMaincnt: "+str(maincnt),favcr,favcg,favcb,10,1,12)
						gputchr(sysscr,0,0,str((viewportw,viewporth)),255,255,255,12,0)
						gputchr(sysscr,0,12,str(keyRepeat_t),255,255,255,12,0)
						gputchr(sysscr,0,24,str(keyDown),255,255,255,12,0)
						gputchr(sysscr,0,36,str(keyRepeat),255,255,255,12,0)
		
						#if mouserx+mousery != 0:
						#		print("Mouse: ",mouseX,mouseY)
		
						i=0
		
						# Feed in focussed window's attributes.
						# If it doesn't exist, junk values will be used.
						
						if app_focus > -1:
								fcx=posx[winid.index(app_focus)]
								fcy=posy[winid.index(app_focus)]
								fcw=sizex[winid.index(app_focus)]
								fch=sizey[winid.index(app_focus)]
								fci=winid.index(app_focus)
						else:
								fcx=-2
								fcy=-2
								fcw=1
								fch=1
								fci=-1
		
						for i in range(0,app_amount):
								app_nofoc=False
								if app_focus < -1:
										app_nofoc=True
		
								# only allow non-focussed apps to run here. The focussed one will be drawn later.
								try:
										if i != winid.index(app_focus):
												app_nofoc=True
								except ValueError:
										app_nofoc = True
								if app_nofoc:
										posx[i]=min(viewportw-sizex[i]/2,max(-8,posx[i]))
										posy[i]=min(viewporth-40,max(8,posy[i]))
										x=posx[i]
										y=posy[i]
										w=sizex[i]
										h=sizey[i]
										wsurface=pygame.Surface((int(sizex[i]),int(sizey[i])))
										if wintype[i]==1:
												gbox(sysscr,posx[i]-2,posy[i]-16,sizex[i]+4,sizey[i]+18,int((favcr+255)/2),int((favcg+255)/2),int((favcb+255)/2),0)
												gputchr(sysscr,posx[i],posy[i]-15,dispname[i],255,255,255,11)
										elif wintype[i]==0:
												gbox(sysscr,posx[i]-2,posy[i]-2,sizex[i]+4,sizey[i]+4,int((favcr+255)/2),int((favcg+255)/2),int((favcb+255)/2),0)
										gbox(wsurface,0,0,sizex[i],sizey[i],bckcolor[i][0],bckcolor[i][1],bckcolor[i][2],0)
										eval(defname[i]+"(winid[i],x,y,w,h)")
										sysscr.blit(wsurface,(x,y))
										try:
												if mouseUp>0 and mouseX>x-2 and mouseY>y-2-14*(wintype[i]==1) and mouseX < x+w+2 and mouseY < y+h+2 and not (mouseX > fcx-2 and mouseY > fcy-2-14*(wintype[fci]==1) and mouseX < fcx+fcw+2 and mouseY < fcy+fch+2):
														app_focus = winid[i]
														mouseUp=0
										except IndexError:
												try:
														if mouseUp>0 and mouseX>x-2 and mouseY>y-2-14*(wintype[i]==1) and mouseX < x+w+2 and mouseY < y+h+2:
																app_focus = winid[i]
																mouseUp=0
												except IndexError:
														pass
										try:
												apptimer[i] += 1
										except IndexError:
												pass
								if i+1 > app_amount-app_killed:
										app_killed=0
										break
				
				mouseUp=False
				keyPressed=False
				keyUp=False
				mousePressed=False

				for event in pygame.event.get():
						if event.type == MOUSEBUTTONDOWN:
								mousePressed=event.button
								mouseDown=event.button
								mouseUp=False
						elif event.type == MOUSEBUTTONUP:
								mouseUp=event.button
								mouseDown=False
						if skkbashutdown or event.type == QUIT:
								print(lng[11])
								return
						if event.type == KEYDOWN and event.key == K_ESCAPE:
								print(lng[12])
								return
						elif event.type == KEYDOWN:
								keyDown = event.key
								keyPressed = event.key
						elif event.type == KEYUP:
								keyUp = event.key
								keyDown = 0

								if keyUp == K_F3:
										fullscreenmode=not fullscreenmode
										viewportchange=True
								if keyUp == K_F5:
										viewportw=400
										viewporth=240
										viewportchange=True
								if keyUp == K_F6:
										viewportw=512
										viewporth=512
										viewportchange=True
								if keyUp == K_F7:
										viewportw=800
										viewporth=480
										viewportchange=True
								if keyUp == K_F9:
										viewportw=1280
										viewporth=720
										viewportchange=True
								if keyUp == K_F10:
										viewportw=1600
										viewporth=900
										viewportchange=True
								if keyUp == K_F11:
										viewportw=1920
										viewporth=1080
										viewportchange=True
								if keyUp == K_F12:
										viewportchange=True
				if keyDown>0:
						keyRepeat_t += 1
						keyRepeat=keyDown*(keyRepeat_t==1 or (keyRepeat_t>12 and (not ((keyRepeat_t-keyRepeat_s) % keyRepeat_d))))
				else:
						keyRepeat_t = 0
						keyRepeat = 0

				if keyRepeat == K_LEFT:
						viewportw += -1
				if keyRepeat == K_RIGHT:
						viewportw += 1
				if keyRepeat == K_UP:
						viewporth += -1
				if keyRepeat == K_DOWN:
						viewporth += 1

				viewportw=min(1920,max(1,viewportw))
				viewporth=min(1080,max(1,viewporth))

				if (maincnt - afktime) < blankscrbyafk:
						if viewportchange:
								viewportchange=False
								if fullscreenmode:
									sysscr = pygame.display.set_mode((viewportw, viewporth),pygame.FULLSCREEN)
								else:
									sysscr = pygame.display.set_mode((viewportw, viewporth))
		
						sysscr.blit(background, taskbar.rect, taskbar.rect)
						sysscr.blit(background, startbtn.rect, startbtn.rect)
						sptaskbar.update()
						spstartbtn.update()
						gline(sysscr,0,viewporth-32,viewportw,viewporth-32,100,130,160,3)
		
						# drawing the focussed window
		
						if app_focus > -1:
								i=winid.index(app_focus)
								posx[i]=min(viewportw-sizex[i]/2,max(-8,posx[i]))
								posy[i]=min(viewporth-40,max(8,posy[i]))
								x=posx[i]
								y=posy[i]
								w=sizex[i]
								h=sizey[i]
								wsurface=pygame.Surface((int(sizex[i]),int(sizey[i])))
								if wintype[i]==1:
										gbox(sysscr,x-2,y-16,sizex[i]+4,sizey[i]+18,favcr,favcg,favcb,0)
										gputchr(sysscr,x,y-15,dispname[i],255,255,255,11)
								elif wintype[i]==0:
										gbox(sysscr,x-2,y-2,sizex[i]+4,sizey[i]+4,favcr,favcg,favcb,0)
								gbox(wsurface,0,0,sizex[i],sizey[i],bckcolor[i][0],bckcolor[i][1],bckcolor[i][2],0)
								eval(defname[i]+"(winid[i],x,y,sizex[i],sizey[i])")
								try:
										apptimer[i] += 1
								except IndexError:
										pass
								sysscr.blit(wsurface,(x,y))
		
						if mouseDown==0: app_dragged=-1
						sptaskbar.draw(sysscr)
						spstartbtn.draw(sysscr)
						startbtn.startbtnborder()
						taskbar.puttaskboxes()
						gputchr(sysscr,viewportw-64,viewporth-31,systime.strftime(lng[9]),255,255,255,12,1)
						gputchr(sysscr,viewportw-64,viewporth-17,systime.strftime(lng[10]),255,255,255,12,1)
						renderNotify()
						#gbox(sysscr,mouseX-8,mouseY-8,16,16,255,255,255,0)		# debug box for where the mouse is
				else:
						gbox(sysscr,0,0,viewportw,viewporth,0,0,0,0)
				
				pygame.display.flip()
				maincnt += 1

# --- language pack init

lng=[]
try:
		lngfile=open("lang_"+lang+".lng","r")
		for i in lngfile.readlines():
				lng.append(i.strip("\r\n"))
		lngfile.close()
except FileNotFoundError:
		for i in range(0,languagepacklinesmin):
				lng.append("???")
teststring=lng[1]

# --- Jump into the main function
if __name__ == '__main__': main()
