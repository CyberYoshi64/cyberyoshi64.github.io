#!/usr/bin/python3

import os, sys,shutil

TITLEIDS = {
	"EUR": "0x1A1C",
	"USA": "0x16DE",
	"JPN": "0x1172",
}

DLCORDER = [
	"GALAXIAN",
	"PACMAN",
	"XEVIOUS",
	"GALAGA",
	"MAPPY",
	"DIGDUG",
	"DRUAGA",
	"B_CITY",
	"S_LUSTER",
	"SKYKID",
	"D_BUSTER",
	"GENPEI",
	"BABEL",
	"A_VALKYRIE",
	"YOKAI",
	"W_MOMO",
	"WAGAN"
]

def fileDelete(f:str) -> None:
	try: os.remove(f)
	except: pass

def buildRsf(outf:str, uniqueid:str, romfs:str="./romfs", contidx:int=0) -> None:
	with open(outf,"wb") as f:
		f.write(b'RomFs:\n  RootPath: "%s"\n\n' % romfs.encode())
		f.write(b'BasicInfo:\n  CompanyCode: cy\n')
		f.write(b'TitleInfo:\n  Category: AddOnContents\n')
		f.write(b'  UniqueId: %s\n' % uniqueid.encode())
		f.write(b'  ContentsIndex: %d\n' % contidx)

cfaArg = ""
cfaNoDLCArg = ""
for i in range(2+len(DLCORDER)):
	cfaArg+="-i {0}.cfa:{0}:{0} ".format(i)
	if i==1: cfaNoDLCArg = cfaArg

## Build icon
print(":: Building icon...")
os.chdir("exefs")
if not os.path.exists("icon.icn"): os.system("./buildIcon.sh")
os.chdir("..")

## Build CFA
print(":: Building CIA...")

### EUR
print("- EUR")
buildRsf("__main.rsf", TITLEIDS["EUR"])
os.system("makerom -f cfa -o 0.cfa -icon exefs/icon.icn -rsf __main.rsf")
os.system("makerom -f cfa -o 1.cfa -rsf __main.rsf")
os.system("makerom -f cia {} -ver 65535 -o DLCEUR.cia".format(cfaNoDLCArg))

### USA
print("- USA")
buildRsf("__main.rsf", TITLEIDS["USA"])
os.system("makerom -f cfa -o 0.cfa -icon exefs/icon.icn -rsf __main.rsf")
os.system("makerom -f cfa -o 1.cfa -rsf __main.rsf")
os.system("makerom -f cia {} -ver 65535 -o DLCUSA.cia".format(cfaNoDLCArg))

## JPN
print("- JPN")
buildRsf("__main.rsf", TITLEIDS["JPN"])
os.system("makerom -f cfa -o 0.cfa -icon exefs/icon.icn -rsf __main.rsf")
os.system("makerom -f cfa -o 1.cfa -rsf __main.rsf")
idx = 2
for i in DLCORDER:
	if not os.path.exists("./content/"+i):
		print("  - "+i+" (not found)")
		shutil.copytree("./content/replacement","./content/"+i, dirs_exist_ok=True)
	else: print("  - "+i)
	buildRsf("__gen.rsf", TITLEIDS["JPN"], "./content/"+i, idx)
	os.system('makerom -f cfa -o {0}.cfa -rsf __gen.rsf'.format(idx))
	idx+=1
os.system("makerom -f cia {} -ver 65535 -o DLCJPN.cia".format(cfaArg))

fileDelete("__main.rsf")
fileDelete("__gen.rsf")

for i in range(2+len(DLCORDER)):
	fileDelete("{}.cfa".format(i))