#!/bin/sh

bannertool makesmdh -s "PTC3 Dummy DLC" -l "Dummy DLC for SmileBASIC" -p "CyberYoshi64" -i icon.png -o icon.icn -r japan,northamerica,europe,australia -f visible,nosavebackups \
-gs "SB3-Platzhalter-DLC" -gl "Platzhalter-DLC für SmileBASIC"